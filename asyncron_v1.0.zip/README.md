# Asyncron 📺

**Asyncron** is a modern Chrome extension designed to revolutionize asynchronous communication. It allows you to record your screen and camera, and bundle the recording together with any related files (code, documents, images, audio, and links) into a single, cohesive `.async` package.

Instead of sending an email or a WhatsApp message with a scattered list of attachments and a separate video link, Asyncron lets you send **one single file**. When the recipient opens the `.async` file in the Asyncron viewer, they are presented with a beautiful, interactive "Retro TV" interface where they can watch your video and easily extract all the bundled attachments.

## 🚀 Key Features

*   **Mixed-Mode Recording:** Record your screen, your camera, or both simultaneously (Picture-in-Picture).
*   **Smart Bundling:** Attach any type of file to your video. The extension automatically detects and categorizes them:
    *   💻 **Code:** Extensive support for modern programming languages (`.js`, `.py`, `.c`, `.rs`, `.html`, etc.)
    *   📄 **Documents:** PDFs, Word docs, spreadsheets, etc.
    *   🖼️ **Media:** Images, audio files, and secondary videos.
    *   🔗 **Links:** Attach direct URLs that will open in a new tab when clicked.
*   **The `.async` Format:** A specialized bundle (based on the standard `tar` format) that groups your video, files, and a manifest into a single, E2E encryption-friendly file.
*   **Interactive Viewer:** A built-in local viewer that runs entirely in your browser. Drag and drop any `.async` file to unveil a realistic TV interface. Click the TV to download the video, or click the buttons on the bottom panel to extract your attachments.
*   **Auto-Detection:** If you receive an `.async` file via WhatsApp Web or download it from anywhere, the extension will automatically detect the download and invite you to open it in the Viewer.

## 🛠️ Use Cases (Why use Asyncron?)

*   **Code Reviews & Bug Reports:** Record your screen demonstrating a bug, and bundle the exact code files (`.js`, `.py`), log files, and a link to the Jira ticket. The developer receives everything in one package.
*   **Client Presentations:** Send a personalized video explaining a proposal, bundled with the PDF contract and an image mockup.
*   **Educational Contexts:** Teachers can record a lesson and bundle it with the presentation slides, extra reading links, and audio clips.
*   **Asynchronous Standups:** Give your daily update in video format and attach any relevant links or files you worked on.

## 💻 How to Use

1.  **Create a Bundle:**
    *   Open the Asyncron extension popup.
    *   Choose your recording source (Screen, Camera, or Both) and click **REC**.
    *   While recording or after stopping, add your files using **+ Add files** or **+ Add Link**.
    *   Click **CREATE BUNDLE** to generate and download your `.async` file.

2.  **View a Bundle:**
    *   If you just downloaded an `.async` file, the extension will automatically prompt you to view it.
    *   Alternatively, open the extension, go to the **VIEWER** tab, and drag & drop the `.async` file.
    *   Click the interactive icons on the realistic TV panel to extract the files you need!

## 📦 Installation & Developer Setup

To run this extension locally:

1. Clone or download this repository.
2. Open Google Chrome and navigate to `chrome://extensions/`.
3. Enable **Developer mode** in the top right corner.
4. Click **Load unpacked** and select the `asyncron` folder.

Enjoy seamless asynchronous communication!
